# Data Breach Exposure Analyzer

![Python](https://img.shields.io/badge/python-3.8+-blue)
![License: MIT](https://img.shields.io/badge/license-MIT-green)
![Status](https://img.shields.io/badge/status-active-brightgreen)

This tool checks whether emails have been involved in public data breaches using HaveIBeenPwned API.

## Features
- Check one or multiple email addresses
- CLI and Jupyter Notebook support
- Free & open source (MIT License)

## Getting Started
1. Add your emails to `data/emails.csv`
2. Add your API key in the script or prompt
3. Run `main.py` or open the notebook

## License
MIT
